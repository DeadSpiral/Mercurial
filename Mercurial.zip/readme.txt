Extract to folder first before running.
Fixed Version, 2.1.

Steps:

Turn off your antivirus
and then run it

if it still didn't work then contact merc#0002